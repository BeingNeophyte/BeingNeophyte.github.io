// This is a coppercube behavior which controls the volume for music and sound.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_Volume_Manager" description="Volume Manager">
		<property name="Music" type="bool" default="true" />
		<property name="Sound" type="bool" default="false" />
	</behavior>
*/


behavior_Volume_Manager = function()
{	//set initial volumes 
	ccbSetCopperCubeVariable("#music.volume",100);
	ccbSetCopperCubeVariable("#sound.volume",100);
	ccbSetCopperCubeVariable("#master.volume",100)
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_Volume_Manager.prototype.onAnimate = function(node, timeMs)
{	
	//Get All the Volume Manager Variables we are going to use
	this.Music_Volume = ccbGetCopperCubeVariable("#music.volume");
	this.Sound_Volume = ccbGetCopperCubeVariable("#sound.volume");
	this.Master_Volume = ccbGetCopperCubeVariable("#master.volume");
	this.Play_3D = ccbGetCopperCubeVariable("#3D.sound");

	//set master volume 
	ccbSetCopperCubeVariable("#system.soundvolume",this.Master_Volume)
	
	//Set Volume For all the soundnodes
	var count = ccbGetSceneNodeChildCount(node);
	for(var i=0; i<count; ++i)
	{
		var child = ccbGetChildSceneNode(node, i);
		//for music Nodes only
		if (this.Music == true && this.Sound == false)
		{	
			ccbSetSceneNodeProperty(child,"Volume",this.Music_Volume)
		}
		
		//for sound Nodes only
		if (this.Music == false && this.Sound == true)
		{	
			ccbSetSceneNodeProperty(child,"Volume",this.Sound_Volume)

		}
	}
/*	//to Turn off All 3D sounds and make them as 2D And Vice Versa -//not recommended //
	
	var rootnode = ccbGetRootSceneNode();
	var rootcount = ccbGetSceneNodeChildCount(rootnode);
	for(var i=0; i<rootcount; ++i)
	{
		var child = ccbGetChildSceneNode(rootnode, i);
		var childcount = ccbGetSceneNodeChildCount(child);
		var nodeType = ccbGetSceneNodeProperty(child,"Type");
		for(var j=0; j<childcount ; ++j)
		{
			var nested_child = ccbGetChildSceneNode(child,j);
			var nested_nodeType = ccbGetSceneNodeProperty(nested_child,"Type");
			if (nested_nodeType == "sound" && this.Play_3D == "false")
				ccbSetSceneNodeProperty(nested_child,"PlayAs2D",true);
			if (nested_nodeType == "sound" && this.Play_3D == "true")
				ccbSetSceneNodeProperty(nested_child,"PlayAs2D",false);
		}
		
		if(nodeType == "sound" && this.Play_3D == "false")
			ccbSetSceneNodeProperty(child,"PlayAs2D",true);
		if(nodeType == "sound" && this.Play_3D == "true")
			ccbSetSceneNodeProperty(child,"PlayAs2D",false);
	}	*/	
}

